---
name: vault-watch
description: >-
  Generate a treasury briefing for a Squads multisig vault: pending
  proposals, token balances, and lending health factors. All data is
  fetched from real Solana RPC calls — never synthesized.
version: "0.1.0"
author: ZeroClaw Labs
license: MIT
category: tools
tags:
  - Community
  - DeFi
  - Solana
permissions: []
---

# Vault Treasury Briefing

Call this tool when the user asks about their Squads vault status, proposals, balances, or portfolio health. Returns a structured summary of on-chain data.

Also suitable for scheduled triggers (ZeroClaw SOP cron) — e.g. a daily briefing every morning at 08:00.

## Goals

- give the user a clear snapshot of their vault's current state
- show pending proposals with approval counts
- show token balances in human-readable units
- report lending health factors when available
- all data is real — never simulate, estimate, or fill with placeholder values

## Parameters

This plugin takes no user-facing parameters. The vault address and RPC URL come from the host-injected `__config` jail.

## Usage

### 1. Call the plugin

Call with empty or minimal args:
```json
{}
```

### 2. Handle the response

**Success:**
```json
{
  "success": true,
  "output": "{\"pending_proposals\":2,\"ready_proposals\":0,\"executed_proposals\":1,\"expiring_soon\":1,\"balances\":[{\"mint\":\"EPjFWdd5...\",\"symbol\":\"USDC\",\"amount\":\"45230000000\",\"decimals\":6},{\"mint\":\"So1111111...\",\"symbol\":\"SOL\",\"amount\":\"124000000000\",\"decimals\":9}],\"lending_positions\":[{\"protocol\":\"Kamino\",\"health_factor\":1.32,\"status\":\"healthy\"}]}"
}
```
→ Parse and format for the user.

**Read-only error:**
```json
{
  "success": false,
  "error": "RPC error: failed to fetch vault data"
}
```
→ Report the error. Do not fabricate data. If RPC is down, suggest the user check their RPC URL.

## Output format

Use this structure:

```text
📊 Daily Treasury Briefing

Proposals: 2 pending, 0 ready, 1 executed, 1 expiring soon

Balances:
  45,230 USDC
  124 SOL

Lending Health:
  Kamino: HF=1.32 ✅
  Drift: HF=1.08 ⚠️ (below 1.15)
```

For errors:

```text
❌ Could not fetch vault data

[Specific error message]

Try again later or check your RPC configuration.
```

## Rules

- Never fabricate or estimate balance data. If RPC is unreachable, say so.
- Never return data for a vault other than the configured one.
- Never prompt the user to modify their vault address in chat — it's set in config.
- For scheduled/daily briefings, keep the output concise (under 200 tokens if possible).
- The plugin is read-only. It cannot create proposals, move funds, or sign anything.
