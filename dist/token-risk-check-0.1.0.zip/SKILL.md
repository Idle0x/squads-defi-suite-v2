---
name: token-risk-check
description: >-
  Analyze an SPL token's risk factors by querying real on-chain mint
  account data via Solana RPC. Returns a risk level (Red/Amber/Green)
  based on mint authority, freeze authority, Token-2022 extensions,
  and holder concentration. Never synthesizes fake scores.
version: "0.1.0"
author: ZeroClaw Labs
license: MIT
category: tools
tags:
  - Community
  - DeFi
  - Solana
permissions: []
---

# Token Risk Check

Call this tool when the user wants to check if a token is safe before swapping, receiving, or interacting with it. Returns real on-chain evidence — never an AI-generated risk score.

## Goals

- give the user a clear, honest risk assessment based on on-chain facts
- detect dangerous token patterns: active mint authority, freeze authority, permanent delegate, transfer hooks
- classify into Red/Amber/Green with actionable advice
- never fabricate or estimate risk — return honest errors when data is unavailable

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `mint` | string | yes | The SPL token mint address to analyze |

## Usage

### 1. Parse the request

The user may provide:
- A mint address directly: "check EPjFWdd5..."
- A token symbol they want checked: "is USDC safe?" — resolve the symbol to a mint address using known addresses

Known safe mints:
- USDC: `EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`
- USDT: `Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB`
- SOL: `So11111111111111111111111111111111111111112`
- JitoSOL: `J1toso1uCk3QLmjYXTh8uU9kysiD8L6VZKUq7RqQ3R3`
- mSOL: `mSoLzYCxHdYgdzU16g5cB6nZ3gQtRzPvGcJKn7oK3z`
- bSOL: `bSoL13r4TkiE4KumL71Ls4Fj8i4yLZYp3vQzjR5t2a`

**Do not guess mint addresses.** If the user provides a symbol you don't recognize, ask for the full mint address.

### 2. Call the plugin

```json
{
  "mint": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
}
```

### 3. Handle the response

**Success (low risk):**
```json
{
  "success": true,
  "output": "{\"mint\":\"EPjFWdd5...\",\"symbol\":\"USDC\",\"risk_level\":\"green\",\"mint_authority\":\"Revoked\",\"freeze_authority\":\"None\",\"token2022_extensions\":[],\"holder_concentration\":\"Low\"}"
}
```

**Success (high risk):**
```json
{
  "success": true,
  "output": "{\"mint\":\"HAXXED...\",\"risk_level\":\"red\",\"mint_authority\":\"Active\",\"freeze_authority\":\"Active\",\"token2022_extensions\":[\"TransferHook\",\"PermanentDelegate\"],\"holder_concentration\":\"High\"}"
}
```

## Output format

Use this structure:

**Low risk:**
```text
🟢 USDC — Low Risk

Mint authority: Revoked  ✅
Freeze authority: None  ✅
Token-2022: No extensions
Holder concentration: Low

Safe to use.
```

**Medium risk:**
```text
🟡 TOKEN — Medium Risk

Mint authority: Active ⚠️
Freeze authority: None ✅
Token-2022: No extensions

Review before interacting.
```

**High risk:**
```text
🔴 TOKEN — HIGH RISK

Mint authority: Active ❌
Freeze authority: Active ❌
Token-2022: Permanent delegate, Transfer hook ❌
Holder concentration: High

HIGH RISK — review carefully before interacting.
```

**Error:**
```text
❌ Could not analyze token

[Specific error]

Possible causes: invalid mint address, RPC unavailable, or the token doesn't exist on-chain.
```

## Risk Level Guide

| Level | Meaning |
|-------|---------|
| 🟢 **Low (Green)** | Mint authority revoked, no freeze authority, no dangerous Token-2022 extensions. Standard safe token pattern. |
| 🟡 **Medium (Amber)** | Some flags active (e.g. active mint authority but no freeze). Review before swapping or accepting. |
| 🔴 **High (Red)** | Multiple danger flags: active mint authority + freeze authority, permanent delegate, or transfer hooks. Exercise extreme caution. |

## Rules

- Never fabricate or estimate risk data. If the RPC call fails, say so.
- Never mark a token as safe if the plugin returns a red risk level.
- Never guess a mint address from a symbol you don't recognize — ask the user for the full address.
- Always show the specific on-chain facts that drove the risk level, not just the level.
- The plugin is read-only. It cannot move funds or sign anything.
