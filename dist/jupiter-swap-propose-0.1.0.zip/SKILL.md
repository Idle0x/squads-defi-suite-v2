---
name: jupiter-swap-propose
description: >-
  Build a Jupiter swap transaction wrapped in a Squads v4 multisig proposal.
  Fetches a real Jupiter quote via HTTP, checks 4 Rust-enforced guardrails
  (mint allowlist, slippage, notional, daily cap), and returns an unsigned
  meta-transaction for human approval in the Squads app.
version: "0.1.0"
author: ZeroClaw Labs
license: MIT
category: tools
tags:
  - Community
  - DeFi
  - Solana
permissions: []
---

# Jupiter Swap → Squads Proposal

Call this tool when the user asks to swap one Solana token for another (e.g. "swap 10 SOL for USDC"). The plugin fetches a live Jupiter quote, checks all guardrails in Rust code, and builds a Squads v4 proposal the human reviews on their phone.

## Goals

- turn plain-English swap requests into correct Jupiter parameters
- always fetch a real quote — never simulate or estimate prices
- enforce all 4 guardrails (mint allowlist, slippage, notional, daily cap) before building the proposal
- return clear, actionable output the user can open in the Squads app
- never bypass guardrails even if the user asks to

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `input_mint` | string | yes | Source token mint address (e.g. `So11111111111111111111111111111111111111112` for SOL) |
| `output_mint` | string | yes | Destination token mint address (e.g. `EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v` for USDC) |
| `amount` | string | yes | Amount in source token's smallest unit (lamports for SOL, 10^decimals for SPL). Pass as string to avoid precision loss. |
| `slippage_bps` | integer | no | Max slippage in basis points. Defaults to config value if omitted. 100 = 1%. |

## Usage

### 1. Parse the request

Extract from the user's natural language:
- Source token (SOL, USDC, or by mint address)
- Destination token
- Amount (convert from human-readable: 10 SOL = 10_000_000_000 lamports)

Known mint addresses for common tokens:
- SOL: `So11111111111111111111111111111111111111112`
- USDC: `EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`
- USDT: `Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB`
- JitoSOL: `J1toso1uCk3QLmjYXTh8uU9kysiD8L6VZKUq7RqQ3R3`
- mSOL: `mSoLzYCxHdYgdzU16g5cB6nZ3gQtRzPvGcJKn7oK3z`
- bSOL: `bSoL13r4TkiE4KumL71Ls4Fj8i4yLZYp3vQzjR5t2a`

### 2. Call the plugin

Construct the args JSON:
```json
{
  "input_mint": "So11111111111111111111111111111111111111112",
  "output_mint": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  "amount": "10000000000",
  "slippage_bps": 100
}
```

### 3. Handle the response

**Success:**
```json
{
  "success": true,
  "output": "{\"proposal_address\":\"...\",\"swap_description\":\"10 SOL → ~2,300 USDC\",\"slippage_bps\":100}"
}
```
→ Tell the user the proposal was created and instruct them to open the Squads app on their phone to review and approve.

**Guardrail denial:**
```json
{
  "success": false,
  "error": "Denied: Notional value $150,000 exceeds max notional $1,000"
}
```
→ Explain which guardrail was hit and what the user can do (e.g. "Swap exceeds the daily cap. Wait until tomorrow or ask an admin to increase the limit.")

**Error:**
```json
{
  "success": false,
  "error": "RPC error: failed to fetch Jupiter quote"
}
```
→ Report the error clearly. Do not retry without user's request.

## Output format

Use this structure in your response to the user:

```text
✅ Swap proposal created!

Swap: 10 SOL → ~2,300 USDC
Slippage: 1% max

Open the Squads app on your phone to review and approve:
https://app.squads.so/proposal/<address>

The agent proposed. The multisig disposes. 🔐
```

For a denial:

```text
❌ Swap denied

Reason: [specific guardrail message]

[Actionable advice for the user]
```

## Rules

- Never modify `input_mint`, `output_mint`, or `amount` after getting them from the user.
- Never tell the user to bypass guardrails. The guardrails exist for safety and are enforced in Rust code that you cannot override.
- Never call the plugin without a real user request. Do not pre-emptively create proposals.
- Never fabricate a quote or estimated price. Always let the plugin fetch from Jupiter.
- If the plugin returns a denial, explain the specific guardrail that triggered and what the user can do about it.
- If the user asks for a swap they don't have permission for, say so directly — do not try to work around the guardrails.
