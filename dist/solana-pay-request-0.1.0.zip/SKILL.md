---
name: solana-pay-request
description: >-
  Build a Solana Pay URL for payment requests. The recipient address is
  enforced by operator config — the LLM cannot redirect payments to a
  different address. Returns a QR-code-ready solana: URL.
version: "0.1.0"
author: ZeroClaw Labs
license: MIT
category: tools
tags:
  - Community
  - DeFi
  - Solana
permissions: []
---

# Solana Pay Request

Call this tool when the user wants to request a payment from someone (e.g. "charge table 4 for 25 USDC" or "send me a payment request for 10 SOL"). Returns a `solana:` URL the payer scans with any Solana wallet.

## Goals

- turn payment requests into correct Solana Pay URLs
- always use the config-enforced recipient address — never accept a recipient from the user
- support both SOL and SPL token payments
- return a URL the payer can scan with Phantom, Backpack, Solflare, or any wallet

## Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `amount` | string | yes | Payment amount in smallest unit (lamports for SOL, 10^decimals for SPL). Pass as string. |
| `spl_mint` | string | no | SPL token mint address. Omit for SOL. |
| `label` | string | no | Merchant label (defaults to config value or empty). |
| `message` | string | no | Description shown to the payer (e.g. "Table 4 dinner bill"). |
| `memo` | string | no | Optional on-chain memo. |

Known mint addresses:
- SOL: omit `spl_mint` entirely
- USDC: `EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`
- USDT: `Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB`

## Usage

### 1. Parse the request

Extract from natural language:
- Amount (convert human-readable to smallest unit)
- Token (SOL or specific SPL token)
- Optional message describing what the payment is for
- Optional memo

**Critical: Do NOT accept a recipient address from the user. The recipient is set in config and cannot be changed through the plugin.**

### 2. Call the plugin

```json
{
  "amount": "25000000",
  "spl_mint": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  "label": "My Store",
  "message": "Table 4 dinner bill",
  "memo": "table-4"
}
```

For a SOL payment, omit `spl_mint`:
```json
{
  "amount": "10000000000",
  "message": "Consultation fee"
}
```

### 3. Handle the response

**Success:**
```json
{
  "success": true,
  "output": "solana:EPjFWdd5...?amount=25000000&recipient=GfQkes...&label=My+Store&message=Table+4+dinner+bill&memo=table-4"
}
```
→ The URL is ready to share. Tell the user to send it to the payer. The payer opens it with their wallet app to approve the payment.

**Error:**
```json
{
  "success": false,
  "error": "Invalid amount: exceeds maximum"
}
```
→ Report the error and suggest a fix.

## Output format

Use this structure:

```text
✅ Payment URL built

Amount: 25 USDC
Recipient: GfQkes...jmCW (enforced by config)
Memo: table-4

Share this link with the payer:
solana:EPjFWdd5...?amount=25000000&...
```

For the payer instructions:
```text
The payer opens this link on their phone. Phantom, Backpack,
or Solflare will show the payment details. They tap approve
to send the funds. ✅
```

## Rules

- Never accept a recipient address from the user. The recipient is set in config and cannot be changed through the plugin.
- If the user asks to send to a different address, explain that the recipient is enforced by operator configuration for security.
- Always convert amounts to the smallest unit (lamports for SOL, 10^decimals for SPL tokens).
- The payer's wallet sends the funds directly to the configured recipient. The agent never holds or touches the funds.
